/*package com.niit.DataBaseConnection;

/*import java.util.Iterator;
import java.util.TreeSet;

import com.niit.Dao.UserDao;
import com.niit.DaoImpl.UserDaoImpl;
import com.niit.Model.Employee;
import com.niit.Model.Users;
*/
/*public class TestDB {
public static void main(String[] args) {
	String skill = new String("Java");
	System.out.println("select employeeId from Employee where skills ='"+skill+"'");
	/*
	DataBaseConnection.getConnection();
	
	UserDao userDao=new UserDaoImpl();//upcasting
	
	Employee employee=new Employee();
	employee.setUserId(112);
	employee.setSalary("20955");
	employee.setSkills("Java");
	
	
	Users user=new Users(112,"yashaswini","8310045512","Hassan");
	userDao.save(user);
	userDao.printUserDetails();
	userDao.updateEmployee(employee);
	userDao.Delete( 116);
	}
	
}
*/