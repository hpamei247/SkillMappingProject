package com.niit.DataBaseConnection;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {
	public static Connection getConnection()
	{
		
		
		 Connection con=null;
		 try {
			 Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con= DriverManager.getConnection("jdbc:sqlserver://172.23.237.11; databaseName=Himdailung_Project;user=sa;password=P@ssw0rd");
		} catch (SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}
         System.out.println("connected to database success");
     

		
		return con;
		
	}
	
	
	
	
	
}
